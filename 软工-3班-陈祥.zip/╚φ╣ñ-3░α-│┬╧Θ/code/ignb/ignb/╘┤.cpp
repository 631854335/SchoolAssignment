#include <stdio.h>
#include <Windows.h>
#include <conio.h>
#ifndef __TUIXIANGZI_H__
#define __TUIXIANGZI_H__

#define _CRT_SECURE_NO_WARNINGS 1

#define ROW 12   //��ͼ����
#define COL 12   //��ͼ����
#define NUM 5   //��ͼ����
enum MENU
{
	EXIT,
	PLAY
};

struct MAP
{
	const int row;
	const int col;
	char map[ROW][COL];
};

void menu();  //�˵�

void game();  //��Ϸʵ�ֺ���

void print_map(char(*map)[COL], const int *row, const int *col);  //��ӡ��ͼ

void find_man(char(*map)[COL], const int *row, const int *col, int *x, int *y);  //�ҵ���ҵ�����

void player_act(char(*map)[COL], int *x, int *y);  //��ҿ���С���ж�

int is_win(char(*map)[COL], const int *row, const int *col);    //�ж��Ƿ�ʤ��

#endif  //__TUIXIANGZI_H__

#define _CRT_SECURE_NO_WARNINGS 1



int main()
{
	int input = 0;

	do
	{
		menu();
		printf("��ѡ����Ҫ���еĲ�����>");
		scanf_s("%d", &input);

		switch (input)
		{
		case PLAY:  system("cls"), game(), system("cls");
			break;
		case EXIT:  printf("�����˳���Ϸ\n");
			break;
		default:  printf("��ѡ���ѡ�������ҿ�����\n");
			break;
		}

	} while (input);
	return 0;
}

#define _CRT_SECURE_NO_WARNINGS 1

struct MAP all_map[NUM] =
{ { 8, 8, { { 0, 0, 1, 1, 1, 0, 0, 0 },  //��ͼһ
{ 0, 0, 1, 3, 1, 0, 0, 0 },
{ 0, 0, 1, 0, 1, 1, 1, 1 },
{ 1, 1, 1, 2, 0, 2, 3, 1 },
{ 1, 3, 0, 2, 4, 1, 1, 1 },
{ 1, 1, 1, 1, 2, 1, 0, 0 },
{ 0, 0, 0, 1, 3, 1, 0, 0 },
{ 0, 0, 0, 1, 1, 1, 0, 0 } } },
{ 9, 9, { {1,1,1,1,1,0,0,0,0},   //��ͼ��
{1,4,0,0,1,0,0,0,0},
{1,0,2,2,1,0,1,1,1},
{1,0,2,0,1,0,1,3,1},
{1,1,1,0,1,1,1,3,1},
{0,1,1,0,0,0,0,3,1},
{0,1,0,0,0,1,0,0,1},
{0,1,0,0,0,1,1,1,1},
{0,1,1,1,1,1,0,0,0} } },
{ 7, 10, { { 0, 1, 1, 1, 1, 1, 1, 1, 0, 0 },  //��ͼ��
{ 0, 1, 0, 0, 0, 0, 0, 1, 1, 1 },
{ 1, 1, 2, 1, 1, 1, 0, 0, 0, 1 },
{ 1, 0, 4, 0, 2, 0, 0, 2, 0, 1 },
{ 1, 0, 3, 3, 1, 0, 2, 0, 1, 1 },
{ 1, 1, 3, 3, 1, 0, 0, 0, 1, 0 },
{0,1,1,1,1,1,1,1,1,0} } },
{ 8, 6, { { 0, 1, 1, 1, 1, 0 },    //��ͼ��
{ 1, 1, 0, 0, 1, 0 },
{ 1, 4, 2, 0, 1, 0 },
{ 1, 1, 2, 0, 1, 1 },
{ 1, 1, 0, 2, 0, 1 },
{ 1, 3, 2, 0, 0, 1 },
{ 1, 3, 3, 5, 3, 1 },
{ 1, 1, 1, 1, 1, 1 } } },
{ 8, 8, { { 0, 1, 1, 1, 1, 1, 0, 0 },  //��ͼ��
{ 0, 1, 0, 4, 0, 1, 1, 1 },
{ 1, 1, 0, 1, 2, 0, 0, 1 },
{ 1, 0, 5, 3, 0, 3, 0, 1 },
{ 1, 0, 0, 2, 2, 0, 1, 1 },
{ 1, 1, 1, 0, 1, 3, 1, 0 },
{ 0, 0, 1, 0, 0, 0, 1, 0 },
{ 0, 0, 1, 1, 1, 1, 1, 0 } } } };   //���������ӵ�ͼ���������������Լ���ͼԪ��

void menu()  //�˵�
{
	printf("***********************\n");
	printf("***    1.��ʼ��Ϸ   ***\n");
	printf("***    0.�˳���Ϸ   ***\n");
	printf("***********************\n");
}

void find_man(char(*map)[COL], const int *row, const int *col, int *x, int *y)  //�ҵ���ҵ�����
{
	int i = 0;
	for (i = 0; i < *row; i++)
	{
		int j = 0;
		for (j = 0; j < *col; j++)
		{
			if ((map[i][j] == 4) || (map[i][j] == 7))
			{
				*x = i;
				*y = j;
				return;
			}
		}
	}
}

void print_map(char(*map)[COL], const int *row, const int *col)  //��ӡ��ͼ
{
	int i = 0;

	printf("\n----------------------\n\n");
	for (i = 0; i < *row; i++)
	{
		int j = 0;
		for (j = 0; j < *col; j++)
		{
			switch ((map[i][j]))
			{
			case 0:printf("  ");
				break;
			case 1:printf("��");
				break;
			case 2:printf("��");
				break;
			case 3:printf("��");
				break;
			case 4:printf("��");
				break;
			case 5:printf("��");
				break;
			case 7:printf("��");
				break;
			}
		}
		printf("\n");
	}
	printf("\nW A S D ����С�˵���������\n");
	printf("\n����ʾǽ������ʾ���ӣ����ʾĿ�ĵ�\n���ʾ��ң����ʾ������Ŀ�ĵ��ϣ�����ʾ����Ŀ�ĵ���\n");
	printf("\n----------------------\n\n");
}

int is_win(char(*map)[COL], const int *row, const int *col)    //�ж��Ƿ�ʤ��
{
	int dest = 0;
	int i = 0;
	for (i = 0; i < *row; i++)
	{
		int j = 0;
		for (j = 0; j < *col; j++)
		{
			if (map[i][j] == 2 || map[i][j] == 7)
				return 0;
		}
	}
	return 1;
}
void player_act(char(*map)[COL], int *x, int *y)  //��ҿ���С���ж�
{
	char input = 0;
	switch (input = _getch())
	{
	case 'W':
	case 'w':
	case 38://������
	{
		if (map[(*x) - 1][*y] == 0 && map[*x][*y] == 4)
		{
			map[*x][*y] = 0;
			map[(*x) - 1][*y] = 4;
			--*x;
		}
		else if (map[(*x) - 1][*y] == 0 && map[*x][*y] == 7)
		{
			map[*x][*y] = 3;
			map[(*x) - 1][*y] = 4;
			--*x;
		}
		else if (map[(*x) - 1][*y] == 3 && map[*x][*y] == 7)
		{
			map[*x][*y] = 3;
			map[(*x) - 1][*y] = 7;
			--*x;
		}
		else if (map[(*x) - 1][*y] == 3 && map[*x][*y] == 4)
		{
			map[*x][*y] = 0;
			map[(*x) - 1][*y] = 7;
			--*x;
		}
		else if (map[(*x) - 1][*y] == 0 && map[*x][*y] == 7)
		{
			map[*x][*y] = 3;
			map[(*x) - 1][*y] = 4;
			--*x;
		}
		else if (map[(*x) - 1][*y] == 2 && map[*x][*y] == 4 && map[(*x) - 2][*y] == 0)
		{
			map[*x][*y] = 0;
			map[(*x) - 1][*y] = 4;
			map[(*x) - 2][*y] = 2;
			--*x;
		}
		else if (map[(*x) - 1][*y] == 2 && map[*x][*y] == 7 && map[(*x) - 2][*y] == 0)
		{
			map[*x][*y] = 3;
			map[(*x) - 1][*y] = 4;
			map[(*x) - 2][*y] = 2;
			--*x;
		}
		else if (map[(*x) - 1][*y] == 2 && map[*x][*y] == 7 && map[(*x) - 2][*y] == 3)
		{
			map[*x][*y] = 3;
			map[(*x) - 1][*y] = 4;
			map[(*x) - 2][*y] = 5;
			--*x;
		}
		else if (map[(*x) - 1][*y] == 2 && map[*x][*y] == 4 && map[(*x) - 2][*y] == 3)
		{
			map[*x][*y] = 0;
			map[(*x) - 1][*y] = 4;
			map[(*x) - 2][*y] = 5;
			--*x;
		}
		else if (map[(*x) - 1][*y] == 5 && map[*x][*y] == 7 && map[(*x) - 2][*y] == 3)
		{
			map[*x][*y] = 3;
			map[(*x) - 1][*y] = 7;
			map[(*x) - 2][*y] = 5;
			--*x;
		}
		else if (map[(*x) - 1][*y] == 5 && map[*x][*y] == 4 && map[(*x) - 2][*y] == 0)
		{
			map[*x][*y] = 0;
			map[(*x) - 1][*y] = 7;
			map[(*x) - 2][*y] = 2;
			--*x;
		}
		else if (map[(*x) - 1][*y] == 5 && map[*x][*y] == 4 && map[(*x) - 2][*y] == 3)
		{
			map[*x][*y] = 0;
			map[(*x) - 1][*y] = 7;
			map[(*x) - 2][*y] = 5;
			--*x;
		}
	}
	break;
	case 'S':
	case 's':
	case 40://������
	{
		if (map[(*x) + 1][*y] == 0 && map[*x][*y] == 4)
		{
			map[*x][*y] = 0;
			map[(*x) + 1][*y] = 4;
			++*x;
		}
		else if (map[(*x) + 1][*y] == 0 && map[*x][*y] == 7)
		{
			map[*x][*y] = 3;
			map[(*x) + 1][*y] = 4;
			++*x;
		}
		else if (map[(*x) + 1][*y] == 3 && map[*x][*y] == 7)
		{
			map[*x][*y] = 3;
			map[(*x) + 1][*y] = 7;
			++*x;
		}
		else if (map[(*x) + 1][*y] == 3 && map[*x][*y] == 4)
		{
			map[*x][*y] = 0;
			map[(*x) + 1][*y] = 7;
			++*x;
		}
		else if (map[(*x) + 1][*y] == 0 && map[*x][*y] == 7)
		{
			map[*x][*y] = 3;
			map[(*x) + 1][*y] = 4;
			++*x;
		}
		else if (map[(*x) + 1][*y] == 2 && map[*x][*y] == 4 && map[(*x) + 2][*y] == 0)
		{
			map[*x][*y] = 0;
			map[(*x) + 1][*y] = 4;
			map[(*x) + 2][*y] = 2;
			++*x;
		}
		else if (map[(*x) + 1][*y] == 2 && map[*x][*y] == 7 && map[(*x) + 2][*y] == 0)
		{
			map[*x][*y] = 3;
			map[(*x) + 1][*y] = 4;
			map[(*x) + 2][*y] = 2;
			++*x;
		}
		else if (map[(*x) + 1][*y] == 2 && map[*x][*y] == 7 && map[(*x) + 2][*y] == 3)
		{
			map[*x][*y] = 3;
			map[(*x) + 1][*y] = 4;
			map[(*x) + 2][*y] = 5;
			++*x;
		}
		else if (map[(*x) + 1][*y] == 2 && map[*x][*y] == 4 && map[(*x) + 2][*y] == 3)
		{
			map[*x][*y] = 0;
			map[(*x) + 1][*y] = 4;
			map[(*x) + 2][*y] = 5;
			++*x;
		}
		else if (map[(*x) + 1][*y] == 5 && map[*x][*y] == 7 && map[(*x) + 2][*y] == 3)
		{
			map[*x][*y] = 3;
			map[(*x) + 1][*y] = 7;
			map[(*x) + 2][*y] = 5;
			++*x;
		}
		else if (map[(*x) + 1][*y] == 5 && map[*x][*y] == 4 && map[(*x) + 2][*y] == 0)
		{
			map[*x][*y] = 0;
			map[(*x) + 1][*y] = 7;
			map[(*x) + 2][*y] = 2;
			++*x;
		}
		else if (map[(*x) + 1][*y] == 5 && map[*x][*y] == 4 && map[(*x) + 2][*y] == 3)
		{
			map[*x][*y] = 0;
			map[(*x) + 1][*y] = 7;
			map[(*x) + 2][*y] = 5;
			++*x;
		}
	}
	break;
	case 'A':
	case 'a':
	case 37://������
	{
		if (map[*x][(*y) - 1] == 0 && map[*x][*y] == 4)
		{
			map[*x][*y] = 0;
			map[*x][(*y) - 1] = 4;
			--*y;
		}
		else if (map[*x][(*y) - 1] == 0 && map[*x][*y] == 7)
		{
			map[*x][*y] = 3;
			map[*x][(*y) - 1] = 4;
			--*y;
		}
		else if (map[*x][(*y) - 1] == 3 && map[*x][*y] == 7)
		{
			map[*x][*y] = 3;
			map[*x][(*y) - 1] = 7;
			--*y;
		}
		else if (map[*x][(*y) - 1] == 3 && map[*x][*y] == 4)
		{
			map[*x][*y] = 0;
			map[*x][(*y) - 1] = 7;
			--*y;
		}
		else if (map[*x][(*y) - 1] == 0 && map[*x][*y] == 7)
		{
			map[*x][*y] = 3;
			map[*x][(*y) - 1] = 4;
			--*y;
		}
		else if (map[*x][(*y) - 1] == 2 && map[*x][*y] == 4 && map[*x][(*y) - 2] == 0)
		{
			map[*x][*y] = 0;
			map[*x][(*y) - 1] = 4;
			map[*x][(*y) - 2] = 2;
			--*y;
		}
		else if (map[*x][(*y) - 1] == 2 && map[*x][*y] == 7 && map[*x][(*y) - 2] == 0)
		{
			map[*x][*y] = 3;
			map[*x][(*y) - 1] = 4;
			map[*x][(*y) - 2] = 2;
			--*y;
		}
		else if (map[*x][(*y) - 1] == 2 && map[*x][*y] == 7 && map[*x][(*y) - 2] == 3)
		{
			map[*x][*y] = 3;
			map[*x][(*y) - 1] = 4;
			map[*x][(*y) - 2] = 5;
			--*y;
		}
		else if (map[*x][(*y) - 1] == 2 && map[*x][*y] == 4 && map[*x][(*y) - 2] == 3)
		{
			map[*x][*y] = 0;
			map[*x][(*y) - 1] = 4;
			map[*x][(*y) - 2] = 5;
			--*y;
		}
		else if (map[*x][(*y) - 1] == 5 && map[*x][*y] == 7 && map[*x][(*y) - 2] == 3)
		{
			map[*x][*y] = 3;
			map[*x][(*y) - 1] = 7;
			map[*x][(*y) - 2] = 5;
			--*y;
		}
		else if (map[*x][(*y) - 1] == 5 && map[*x][*y] == 4 && map[*x][(*y) - 2] == 0)
		{
			map[*x][*y] = 0;
			map[*x][(*y) - 1] = 7;
			map[*x][(*y) - 2] = 2;
			--*y;
		}
		else if (map[*x][(*y) - 1] == 5 && map[*x][*y] == 4 && map[*x][(*y) - 2] == 3)
		{
			map[*x][*y] = 0;
			map[*x][(*y) - 1] = 7;
			map[*x][(*y) - 2] = 5;
			--*y;
		}
	}
	break;
	case 'D':
	case 'd':
	case 39://������
	{
		if (map[*x][(*y) + 1] == 0 && map[*x][*y] == 4)
		{
			map[*x][*y] = 0;
			map[*x][(*y) + 1] = 4;
			++*y;
		}
		else if (map[*x][(*y) + 1] == 0 && map[*x][*y] == 7)
		{
			map[*x][*y] = 3;
			map[*x][(*y) + 1] = 4;
			++*y;
		}
		else if (map[*x][(*y) + 1] == 3 && map[*x][*y] == 7)
		{
			map[*x][*y] = 3;
			map[*x][(*y) + 1] = 7;
			++*y;
		}
		else if (map[*x][(*y) + 1] == 3 && map[*x][*y] == 4)
		{
			map[*x][*y] = 0;
			map[*x][(*y) + 1] = 7;
			++*y;
		}
		else if (map[*x][(*y) + 1] == 0 && map[*x][*y] == 7)
		{
			map[*x][*y] = 3;
			map[*x][(*y) + 1] = 4;
			++*y;
		}
		else if (map[*x][(*y) + 1] == 2 && map[*x][*y] == 4 && map[*x][(*y) + 2] == 0)
		{
			map[*x][*y] = 0;
			map[*x][(*y) + 1] = 4;
			map[*x][(*y) + 2] = 2;
			++*y;
		}
		else if (map[*x][(*y) + 1] == 2 && map[*x][*y] == 7 && map[*x][(*y) + 2] == 0)
		{
			map[*x][*y] = 3;
			map[*x][(*y) + 1] = 4;
			map[*x][(*y) + 2] = 2;
			++*y;
		}
		else if (map[*x][(*y) + 1] == 2 && map[*x][*y] == 7 && map[*x][(*y) + 2] == 3)
		{
			map[*x][*y] = 3;
			map[*x][(*y) + 1] = 4;
			map[*x][(*y) + 2] = 5;
			++*y;
		}
		else if (map[*x][(*y) + 1] == 2 && map[*x][*y] == 4 && map[*x][(*y) + 2] == 3)
		{
			map[*x][*y] = 0;
			map[*x][(*y) + 1] = 4;
			map[*x][(*y) + 2] = 5;
			++*y;
		}
		else if (map[*x][(*y) + 1] == 5 && map[*x][*y] == 7 && map[*x][(*y) + 2] == 3)
		{
			map[*x][*y] = 3;
			map[*x][(*y) + 1] = 7;
			map[*x][(*y) + 2] = 5;
			++*y;
		}
		else if (map[*x][(*y) + 1] == 5 && map[*x][*y] == 4 && map[*x][(*y) + 2] == 0)
		{
			map[*x][*y] = 0;
			map[*x][(*y) + 1] = 7;
			map[*x][(*y) + 2] = 2;
			++*y;
		}
		else if (map[*x][(*y) + 1] == 5 && map[*x][*y] == 4 && map[*x][(*y) + 2] == 3)
		{
			map[*x][*y] = 0;
			map[*x][(*y) + 1] = 7;
			map[*x][(*y) + 2] = 5;
			++*y;
		}
	}
	break;
	}
}

void game()  //��Ϸʵ�ֺ���
{
	int i = 0;
	int x = 0;
	int y = 0;
	struct MAP *pmap = NULL;
	printf("\n\nĿǰ�ܹ���%d��,��Ҫ����һ�ؿ�ʼ�棿��>", NUM);
	scanf_s("%d", &i);
	pmap = all_map + i - 1;
	find_man(pmap->map, &(pmap->row), &(pmap->col), &x, &y);
	while (1)
	{
		system("cls");
		print_map(pmap->map, &(pmap->row), &(pmap->col));
		player_act(pmap->map, &x, &y);
		if (is_win(pmap->map, &(pmap->row), &(pmap->col)) && i < NUM)
		{
			system("cls");
			print_map(pmap->map, &(pmap->row), &(pmap->col));
			printf("�������С����\n");
			system("pause");
			pmap++;
			x = 0;
			y = 0;
			i++;
			find_man(pmap->map, &(pmap->row), &(pmap->col), &x, &y);
		}
		else if (i == NUM)
		{
			printf("\nͨ���˰�������������\n");
			return;
		}
	}
}