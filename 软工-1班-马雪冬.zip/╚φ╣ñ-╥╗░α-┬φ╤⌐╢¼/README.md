项目->《推箱子》
=
各项功能介绍如下：
=
![](https://github.com/mxd0919/666/blob/master/1.png)
![](https://github.com/mxd0919/666/blob/master/2.png)
本游戏，可以选择不同关卡（关卡1~35）如下：
=
![](https://github.com/mxd0919/666/blob/master/3.png)
若在游戏途中，误走的话，可进行撤退。
=
![](https://github.com/mxd0919/666/blob/master/4.png)
![](https://github.com/mxd0919/666/blob/master/5.png)
该项目创建在同一个项目中，分为->头文件：function.h->main.cpp->源.cpp;
=
![](https://github.com/mxd0919/666/blob/master/5NWI5D9XFGWQ4PLH16~S%60JB.png)
=
综上，该游戏功能如上所诉！
=


