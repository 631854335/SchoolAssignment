
#include <stdio.h>
#include "function.h"

int main() {
	//printf("hh");
	mainloop();
	return 0;
}